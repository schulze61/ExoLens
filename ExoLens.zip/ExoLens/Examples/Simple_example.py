#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 13:50:44 2020

@author: joeschulze

This example script takes inputs from a csv file and computes the core mass
fraction (CMF) inferred from a planet's mass and radius, including estimates for the
upper and lower uncertainties on CMF. It also calculates the probability that
the CMF inferred from mass and radius are consistent with the CMF expected
from the major refractory abundances, Fe/Mg and Si/Mg, of the host star.

This script also generates a plot of the estimated planetary CMF's vs Radius
for the input sample.
"""


import pandas as pd
import numpy as np
import sys
import os

sys.path.insert(1, os.path.abspath('../'))
sys.path.insert(1, os.path.abspath('../functions'))

from ExoLens import ExoLens
import matplotlib.pyplot as plt


data = pd.read_csv('../DataSets/PlanetSample.csv')


cmfrho_arr = []; cmfrho_uperr_arr = []; cmfrho_lowerr_arr = []
cmfstar_arr = []; sigcmfstar_arr = []
integral_arr = []

for i in range(0, len(data)):
    
    mass = [data['Mass'][i], data['sigM'][i]]
    radius = [data['Radius'][i], data['sigR'][i]]
    abund = [data['FeMg'][i], data['sigFeMg'][i], data['SiMg'][i], data['sigSiMg'][i]] 
    
    
    planet_fname = data['Planet'][i]
    
    #If you do not wish to generate plots, set the optional plot_flag to zero.
    #Default is to do the plotting.
    cmf_rho, cmf_star, P_ho = ExoLens(mass, radius, planet_fname, abund, plot_flag = 1)
    
    
    #append to output arrays. If no CMF star is provided to ExoLens, the integral
    #array is given a "nan".
    cmfrho_arr = np.append(cmfrho_arr, cmf_rho[0])
    cmfrho_uperr_arr = np.append(cmfrho_uperr_arr, cmf_rho[1])
    cmfrho_lowerr_arr = np.append(cmfrho_lowerr_arr, cmf_rho[2])
    cmfstar_arr = np.append(cmfstar_arr, cmf_star[0])
    sigcmfstar_arr = np.append(sigcmfstar_arr, cmf_star[1])
    integral_arr = np.append(integral_arr, P_ho)
    
#Generate CMF vs R plot for sample, because why not?

plt.figure(figsize = (12,8))
plt.errorbar(data['Radius'], cmfrho_arr, yerr = [cmfrho_lowerr_arr, cmfrho_uperr_arr], xerr = data['sigR'], fmt = 'o', markersize = 10, elinewidth = 3, capsize = 5)
plt.ylabel(r'CMF$_\rho$', fontsize = 32)
plt.xlabel(r'Radius (R$_\oplus$)', fontsize = 32)
plt.tick_params('both', direction = 'in', size = 8, labelsize = 24)
plt.ylim([0,100])
plt.savefig('../Outputs/Plots/CMF_v_R_simple_ex')


out = pd.DataFrame({'Planet': data['Planet'],'cmfrho': cmfrho_arr, 'sigcmfp': cmfrho_uperr_arr, 'sigcmfm': cmfrho_lowerr_arr, 'cmfstar': cmfstar_arr, 'sigcmfstar': sigcmfstar_arr, 'P(H0)':integral_arr})

out.to_csv('../Outputs/Results/PlanetSample_ExoLens_simple_example_results.csv')   
    




